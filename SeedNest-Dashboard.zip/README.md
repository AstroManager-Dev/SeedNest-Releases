# SeedNest Analytics – GitHub Pages Dashboard

Fertiges, mobiloptimiertes Dashboard für die öffentlichen Release-Downloads von `AstroManager-Dev/SeedNest-Releases`.

**Start:** Öffne `ANLEITUNG.md`. Das ZIP enthält die GitHub-Ordnerstruktur unter `stats/` sowie `.github/workflows/seednest-analytics.yml`.

Das Dashboard zeigt beim Öffnen aktuelle GitHub-APK-Zähler. Der tägliche Messverlauf beginnt erst ab der ersten GitHub-Actions-Ausführung. Kein Codex und keine zusätzliche Serverinfrastruktur erforderlich.

**Vorgesehene Pages-URL (nach Einrichtung):** https://astromanager-dev.github.io/SeedNest-Releases/
