# SeedNest Analytics – Einrichtung mit GitHub Pages

**Geeignet für Android-Handy und Windows-PC. Kein Codex, kein Raspberry Pi, kein Supabase nötig.**

## Was dieses Paket liefert

- Responsives, dunkles Download-Dashboard für SeedNest.
- **Live-Zahlen:** ruft GitHub Releases bei jedem Öffnen direkt ab.
- **Verlauf:** GitHub Actions speichert einmal täglich alle APK-Downloadzähler in `stats/data/history.json`.
- **Versionsvergleich:** APK-Downloads pro Release; Prüfsummen und sonstige Dateien werden nicht mitgezählt.
- Kostenlos für dein **öffentliches** Repository `AstroManager-Dev/SeedNest-Releases` im üblichen GitHub-Free-Rahmen.
- Keine Nutzerverfolgung, keine Cookies, keine private Cloud, keine API-Schlüssel im Browser.

## Die 4 benötigten Dateien

Nach dem Entpacken enthält das ZIP unter anderem:

```text
SeedNest-Releases/                (bereits vorhandenes GitHub-Repository)
├── stats/
│   ├── index.html                (Dashboard; HTML, CSS und JS in einer Datei)
│   ├── collect.py                (GitHub-Abfrage und tägliche Speicherung)
│   ├── .nojekyll                 (GitHub Pages ohne Jekyll)
│   └── data/
│       └── history.json         (Startwert [] – noch keine historische Messung)
└── .github/
    └── workflows/
        └── seednest-analytics.yml   (Workflow: Erfassen + auf Pages veröffentlichen)
```

**Wichtig:** Im ZIP ist diese Struktur relativ zum bestehenden Repository enthalten. Nicht das ZIP als einzelne Datei hochladen. Nicht den Inhalt des öffentlichen Release-Repositories löschen oder überschreiben. Wenn im Repository bereits Dateien mit denselben Pfaden vorhanden sind, zuerst vergleichen.

## 1. GitHub-Dateien hochladen (Windows – einfachste Methode)

1. ZIP herunterladen und **entpacken**.
2. Repository öffnen: https://github.com/AstroManager-Dev/SeedNest-Releases
3. Mit einem lokalen Git-Klon arbeiten oder im Browser über **Add file → Upload files** die Dateien hochladen. Die Verzeichnisstruktur muss erhalten bleiben (insbesondere `.github/workflows`).
4. Bei Git im lokalen Klon die Ordner `stats` und `.github/workflows/seednest-analytics.yml` ins Repository kopieren und anschließend ausführen:

   ```bash
   git add stats .github/workflows/seednest-analytics.yml
   git commit -m "Add SeedNest download analytics dashboard"
   git push origin main
   ```

5. Der neue Workflow kann nach dem ersten Push zunächst fehlschlagen, wenn GitHub Pages noch nicht aktiviert wurde. Das ist erwartbar: die nächsten Schritte beheben das.

## 2. Einrichtung komplett auf Android (Chrome)

Du brauchst keinen PC. Die Bedienung von GitHub ist im Browser allerdings etwas umständlicher.

1. ZIP in **Downloads** speichern und mit der Android-Datei-App entpacken. Bei Bedarf **versteckte Dateien anzeigen** aktivieren, damit `.github` sichtbar wird.
2. In Chrome https://github.com/AstroManager-Dev/SeedNest-Releases öffnen und anmelden. Falls Menüs fehlen: Chrome-Menü → **Desktopwebsite** aktivieren.
3. Im Repository zuerst den Ordner `stats` anlegen, falls nicht vorhanden. Das geht über **Add file → Create new file**, als Dateipfad `stats/index.html`; anschließend den Inhalt aus `stats/index.html` der ZIP-Datei in den GitHub-Editor kopieren und **Commit changes** wählen. Alternativ: in einem bestehenden Ordner **Add file → Upload files** verwenden.
4. Ebenso `stats/collect.py` und `stats/data/history.json` mit den entsprechenden Pfaden hinzufügen. `.nojekyll` ist optional, weil die Veröffentlichung direkt über den Workflow erfolgt.
5. Über **Add file → Create new file** die Datei `.github/workflows/seednest-analytics.yml` anlegen und ihren Inhalt einfügen. Die Datei mit **Commit changes** speichern. Für diese Datei genügt der GitHub-Webeditor; GitHub erkennt die Verzeichnisstruktur im Dateinamen.
6. Danach die GitHub-Pages-Einstellung wie unten beschrieben aktivieren.

Tipp: Wenn du nicht so viel Text auf dem Handy einfügen willst, kannst du in den jeweiligen Ordnern **Upload files** wählen und die entpackten Dateien einzeln auswählen. Ob du Ordner direkt übertragen kannst, hängt vom Android-Dateimanager und Browser ab. Entscheidend sind die **exakten Zielpfade**.

## 3. GitHub Pages aktivieren

1. Öffne https://github.com/AstroManager-Dev/SeedNest-Releases/settings/pages
2. Unter **Build and deployment → Source** die Option **GitHub Actions** wählen (nicht „Deploy from a branch“).
3. Speichern, falls eine Schaltfläche erscheint.

**Warum GitHub Actions?** Der Tagesstand wird von einem Workflow mit `GITHUB_TOKEN` gespeichert. Solche Commits lösen keine neue automatische Veröffentlichung aus, wenn Pages nur direkt aus einem Branch veröffentlicht wird. Unser Workflow macht **beides in einem Lauf**: Tagesstand speichern und aktualisierte Website aus `stats/` bereitstellen.

## 4. Workflow einmal manuell starten

1. Öffne https://github.com/AstroManager-Dev/SeedNest-Releases/actions
2. Falls gefragt, **Actions aktivieren**.
3. Links **SeedNest Download Dashboard** öffnen.
4. **Run workflow** → Branch `main` → **Run workflow**.
5. Nach erfolgreichem Lauf enthält `stats/data/history.json` den ersten Tagesstand.
6. Danach wird automatisch einmal täglich um ungefähr **05:23 UTC** gemessen. GitHub garantiert keine minutengenaue Ausführung; bei hoher Last oder längerer Inaktivität können Ausführungen verspätet oder ausgelassen werden.

Falls der Workflow wegen „Permission denied to github-actions[bot]“ bei `git push` fehlschlägt: Repository **Settings → Actions → General → Workflow permissions** prüfen. Die Repository-/Organisationsrichtlinien müssen Commits per `GITHUB_TOKEN` zulassen. Bei gesperrtem Branch muss die Schutzregel entsprechend angepasst werden, ohne Schutzmaßnahmen ungeprüft abzuschalten.

## 5. Dashboard aufrufen

Nach erfolgreichem Pages-Deploy (oft einige Minuten, bei GitHub teils bis zu 10 Minuten):

**https://astromanager-dev.github.io/SeedNest-Releases/**

Die tatsächliche öffentliche Pages-URL zeigt GitHub unter **Settings → Pages → Visit site** an.

Für Android kannst du in Chrome das Drei-Punkte-Menü öffnen und **Zum Startbildschirm hinzufügen** wählen.

## Häufige Fragen

**Warum steht bei „letzte 7 Tage“ noch ein Strich?**  
GitHub liefert nur kumulierte Zähler pro Datei, keine historische Tagesauflistung. Erst wenn mindestens 7 Tage Messhistorie vorhanden sind, kann das Dashboard eine belastbare Sieben-Tage-Differenz berechnen.

**Sind das Downloads oder installierte Apps?**  
Nur APK-Dateiabrufe, keine eindeutigen Menschen oder Installationen. Eigene Tests und Mehrfachdownloads zählen mit.

**Was passiert, wenn GitHub 403 meldet?**  
Der öffentliche, anonyme GitHub-API-Zugriff kann zeitweise rate-limitiert sein. Die Seite verwendet dann den letzten gespeicherten Tagesstand, sofern vorhanden.

**Wird etwas kostenpflichtig?**  
Für öffentliche Repositories sind Standard-GitHub-Actions-Runner im üblichen Rahmen kostenlos. Das Dashboard nutzt keine externen kostenpflichtigen Dienste. Keine Zahlungen aktivieren.

**Kann ich die Downloadzahlen vor der Einrichtung rückwirkend pro Tag anzeigen?**  
Nein, über die normale GitHub-Release-API gibt es nur aktuelle kumulierte Asset-Zähler. Das Dashboard erfasst die Tagesstände ab Installation.

**Kann ich die APKs weiter wie bisher veröffentlichen?**  
Ja. Das Dashboard ergänzt ausschließlich den Ordner `stats` und einen isolierten Workflow. Es verändert keine APKs, keine `latest.json`, keinen Changelog und keine Release-Signaturen.

## Sicherheit und Datenschutz

- Das Dashboard ist öffentlich; es zeigt nur bereits öffentlich zugängliche GitHub-Release-Metadaten.
- Persönliche SeedNest-Sammlungen, StrainDB-Daten und Cloud-Konten werden nicht angefasst.
- Keine persönlichen Tokens in `index.html`, `collect.py`, Dateien oder Workflow einfügen.
- Der Workflow nutzt das kurzlebige, automatisch bereitgestellte `GITHUB_TOKEN`.
- Der Workflow benötigt `contents: write`, `pages: write` und `id-token: write` für die angegebenen Jobs.
- Der Workflow speichert in `stats/data/history.json` ausschließlich Tageszahlen und Versionsnamen.

## Aktualisierungen

Die Dateien im Ordner `stats` können später verändert werden. Danach den Workflow erneut ausführen oder auf seinen Trigger warten, damit die neue Seite veröffentlicht wird.

GitHub-Dokumentation:
- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- https://docs.github.com/en/actions/using-workflows/events-that-trigger-workflows#schedule
